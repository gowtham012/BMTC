package com.example.bussreserve;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.shreyaspatil.EasyUpiPayment.EasyUpiPayment;
import com.shreyaspatil.EasyUpiPayment.listener.PaymentStatusListener;
import com.shreyaspatil.EasyUpiPayment.model.TransactionDetails;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class Next extends AppCompatActivity implements PaymentStatusListener {

    EditText amount,upi, nameEdt, descEdt;
    Button button;

    private TextView transactionDetailsTV;
    int UPI_PAYMENT_REQUEST_CODE=11;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);

        Intent i= getIntent();

        amount=findViewById(R.id.amount);
        upi=findViewById(R.id.upi);
        button=findViewById(R.id.submi);

        nameEdt = findViewById(R.id.idEdtName);
        descEdt = findViewById(R.id.idEdtDescription);
        transactionDetailsTV = findViewById(R.id.idTVTransactionDetails);

        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("ddMMyyyyHHmmss", Locale.getDefault());
        String transcId = df.format(c);

        amount.setText(i.getStringExtra("amt"));
      //  Toast.makeText(this, ""+i.getStringExtra("mo")+""+i.getStringExtra("o"), Toast.LENGTH_SHORT).show();

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent upiIntent = new Intent(Intent.ACTION_VIEW);
                String uriString = "upi://pay?pa=amazonupi@paytm&pn=amazon&tr=" + transcId + "&mc=1234&am=" + amount+"&tn=paymentForAmazon";

                upiIntent.setData(Uri.parse(uriString));
                Intent chooser = Intent.createChooser(upiIntent, "Pay with...");

                startActivityForResult(chooser, UPI_PAYMENT_REQUEST_CODE, null);

                /*if(amount.getText().toString().trim().isEmpty()){
                    Snackbar.make(Next.this.getWindow().getDecorView().findViewById(android.R.id.content), "Enter Amount", Snackbar.LENGTH_SHORT).show();
                }
                else if(upi.getText().toString().trim().isEmpty()){
                    Snackbar.make(Next.this.getWindow().getDecorView().findViewById(android.R.id.content), "Enter UPI", Snackbar.LENGTH_SHORT).show();

                }
                else {
                    makepay(amount.getText().toString().trim(),upi.getText().toString().trim(),nameEdt.getText().toString().trim(),descEdt.getText().toString().trim(),transcId);

                }*/
            }
        });






    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == UPI_PAYMENT_REQUEST_CODE) {
                String paymentResponse =data.getStringExtra("response");

            }
        }
    }

    private void makepay(String amount, String upi, String trim, String s, String transcId) {
        final EasyUpiPayment easyUpiPayment = new EasyUpiPayment.Builder()
                .with(this)
                // on below line we are adding upi id.
                .setPayeeVpa(upi)
                // on below line we are setting name to which we are making oayment.

                // on below line we are passing transaction id.
                .setPayeeName(trim)
                // on below line we are passing transaction id.
                .setTransactionId(transcId)
                // on below line we are passing transaction ref id.
                .setTransactionRefId(transcId)
                // on below line we are adding description to payment.
                .setDescription(s)
                .setAmount(amount)
                // on below line we are calling a build method to build this ui.
                .build();
        // on below line we are calling a start
        // payment method to start a payment.
        easyUpiPayment.startPayment();
        // on below line we are calling a set payment
        // status listener method to call other payment methods.
        easyUpiPayment.setPaymentStatusListener(this);

    }

    @Override
    public void onTransactionCompleted(TransactionDetails transactionDetails) {
// on below line we are getting details about transaction when completed.
        String transcDetails = transactionDetails.getStatus().toString() + "\n" + "Transaction ID : " + transactionDetails.getTransactionId();

    }

    @Override
    public void onTransactionSuccess() {
        Toast.makeText(this, "Transaction successfully completed..", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onTransactionSubmitted() {
        Log.e("TAG", "TRANSACTION SUBMIT");
    }

    @Override
    public void onTransactionFailed() {
        Toast.makeText(this, "Failed to complete transaction", Toast.LENGTH_SHORT).show();

    }




    @Override
    public void onTransactionCancelled() {
        Toast.makeText(this, "Transaction cancelled..", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onAppNotFound() {

        Toast.makeText(this, "No app found for making transaction..", Toast.LENGTH_SHORT).show();
    }
}

