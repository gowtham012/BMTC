package com.example.bussreserve;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BookSeatAdapter extends RecyclerView.Adapter<BookSeatAdapter.ViewHolder> {

    ArrayList route=new ArrayList();
    ArrayList cost=new ArrayList();
    ArrayList busnum=new ArrayList();
    ArrayList source=new ArrayList();
    ArrayList destiny=new ArrayList();
    ArrayList time=new ArrayList();
    ArrayList s1=new ArrayList(); ArrayList s11=new ArrayList();
    ArrayList s2=new ArrayList(); ArrayList s12=new ArrayList();
    ArrayList s3=new ArrayList(); ArrayList s13=new ArrayList();
    ArrayList s4=new ArrayList(); ArrayList s14=new ArrayList();
    ArrayList s5=new ArrayList(); ArrayList s15=new ArrayList();
    ArrayList s6=new ArrayList(); ArrayList s16=new ArrayList();
    ArrayList s7=new ArrayList(); ArrayList s17=new ArrayList();
    ArrayList s8=new ArrayList(); ArrayList s18=new ArrayList();
    ArrayList s9=new ArrayList(); ArrayList s19=new ArrayList();
    ArrayList s10=new ArrayList(); ArrayList s20=new ArrayList();
    Context context;

    ArrayList booked=new ArrayList();

    String c1,ca1,c2,ca2,c3,ca3,c4,ca4,c5,ca5,c6,ca6,c7,ca7,c8,ca8,c9,ca9,c10,ca10,c11,ca11,c12,ca12,c13,ca13,c14,ca14,c15,ca15,c16,ca16,c17,ca17,c18,ca18,c19,ca19,c20,ca20;


    public BookSeatAdapter(BookSeat bookSeat, ArrayList route, ArrayList busnum, ArrayList source, ArrayList destiny, ArrayList time, ArrayList cost, ArrayList s1, ArrayList s2, ArrayList s3, ArrayList s4, ArrayList s5, ArrayList s6, ArrayList s7, ArrayList s8, ArrayList s9, ArrayList s10, ArrayList s11, ArrayList s12, ArrayList s13, ArrayList s14, ArrayList s15, ArrayList s16, ArrayList s17, ArrayList s18, ArrayList s19, ArrayList s20) {

        this.context=bookSeat;

        this.route=route;
        this.busnum=busnum;
        this.source=source;
        this.destiny=destiny;
        this.time=time;
        this.cost=cost;

        this.s1=s1;
        this.s2=s2;
        this.s3=s3;
        this.s4=s4;
        this.s5=s5;
        this.s6=s6;
        this.s7=s7;
        this.s8=s8;
        this.s9=s9;
        this.s10=s10;
        this.s11=s11;
        this.s12=s12;
        this.s13=s13;
        this.s14=s14;
        this.s15=s15;
        this.s16=s16;
        this.s17=s17;
        this.s18=s18;
        this.s19=s19;
        this.s20=s20;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.seat_item,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {


        holder.route.setText(route.get(position).toString());
        holder.busnum.setText(busnum.get(position).toString());
        holder.source.setText(source.get(position).toString());
        holder.destiny.setText(destiny.get(position).toString());
        holder.time.setText(time.get(position).toString());
        holder.cost.setText(cost.get(position).toString());

      //  Toast.makeText(context, ""+cost.get(position), Toast.LENGTH_SHORT).show();

        if(s1.get(position).toString().equalsIgnoreCase("not")){
            holder.s1.setVisibility(View.VISIBLE);
        }
         if(s2.get(position).toString().equalsIgnoreCase("not")){
            holder.s2.setVisibility(View.VISIBLE);
        }
         if(s3.get(position).toString().equalsIgnoreCase("not")){
            holder.s3.setVisibility(View.VISIBLE);
        }
         if(s4.get(position).toString().equalsIgnoreCase("not")){
            holder.s4.setVisibility(View.VISIBLE);
        }
         if(s5.get(position).toString().equalsIgnoreCase("not")){
            holder.s5.setVisibility(View.VISIBLE);
        }
         if(s6.get(position).toString().equalsIgnoreCase("not")){
            holder.s6.setVisibility(View.VISIBLE);
        } if(s7.get(position).toString().equalsIgnoreCase("not")){
            holder.s7.setVisibility(View.VISIBLE);
        }
         if(s8.get(position).toString().equalsIgnoreCase("not")){
            holder.s8.setVisibility(View.VISIBLE);
        }
         if(s8.get(position).toString().equalsIgnoreCase("not")){
            holder.s8.setVisibility(View.VISIBLE);
        }
         if(s9.get(position).toString().equalsIgnoreCase("not")){
            holder.s9.setVisibility(View.VISIBLE);
        }
         if(s10.get(position).toString().equalsIgnoreCase("not")){
            holder.s10.setVisibility(View.VISIBLE);
        }
         if(s11.get(position).toString().equalsIgnoreCase("not")){
            holder.s11.setVisibility(View.VISIBLE);
        }
         if(s12.get(position).toString().equalsIgnoreCase("not")){
            holder.s12.setVisibility(View.VISIBLE);
        }
         if(s13.get(position).toString().equalsIgnoreCase("not")){
            holder.s13.setVisibility(View.VISIBLE);
        }
         if(s14.get(position).toString().equalsIgnoreCase("not")){
            holder.s14.setVisibility(View.VISIBLE);
        }
           if(s15.get(position).toString().equalsIgnoreCase("not")){
            holder.s15.setVisibility(View.VISIBLE);
        }  if(s16.get(position).toString().equalsIgnoreCase("not")){
            holder.s16.setVisibility(View.VISIBLE);
        }  if(s17.get(position).toString().equalsIgnoreCase("not")){
            holder.s17.setVisibility(View.VISIBLE);
        }  if(s18.get(position).toString().equalsIgnoreCase("not")){
            holder.s18.setVisibility(View.VISIBLE);
        }  if(s19.get(position).toString().equalsIgnoreCase("not")){
            holder.s19.setVisibility(View.VISIBLE);
        }  if(s20.get(position).toString().equalsIgnoreCase("not")){
            holder.s20.setVisibility(View.VISIBLE);
        }

        if(holder.s1.isChecked()){
            c1="S1 booked";
            booked.add(c1);
        }
        else {
            c1="not";
        }
        if(holder.s2.isChecked()){
            c2="s2 booked";
            booked.add(c2);
        }else {
            c2="not";
        }
        if(holder.s3.isChecked()){
            c3="S3 booked";
            booked.add(c3);
        }else{
            c3="not";
        }
        if(holder.s4.isChecked()){
            c4="S4 booked";
            booked.add(c4);
        }else {
            c4="not";
        }
        if(holder.s5.isChecked()){
            c5="S5 booked";
            booked.add(c5);
        }else {
            c5="not";
        }
        if(holder.s6.isChecked()){
            c6="S6 booked";
            booked.add(c6);
        }else {
            c6="not";
        }
        if(holder.s7.isChecked()){
            c7="S7 booked";
            booked.add(c7);
        }else {
            c7="not";
        }
        if(holder.s8.isChecked()){
            c8="S8 booked";
            booked.add(c8);
        }else {
            c8="not";
        }
        if(holder.s9.isChecked()){
            c9="S9 booked";
            booked.add(c9);
        }else {
            c9="not";
        }
        if(holder.s10.isChecked()){
            c10="S10 booked";
            booked.add(c10);
        }else {
            c10="not";
        }
        if(holder.s11.isChecked()){
            c11="S11 booked";
            booked.add(c11);
        }else {
            c11="not";
        }
        if(holder.s12.isChecked()){
            c12="S12 booked";
            booked.add(c12);
        }else {
            c12="not";
        }
        if(holder.s13.isChecked()){
            c13="S13 booked";
            booked.add(c13);
        }else {
            c13="not";
        }
        if(holder.s14.isChecked()){
            c14="S14 booked";
            booked.add(c14);
        }else {
            c14="not";
        }
        if(holder.s15.isChecked()){
            c15="S15 booked";
            booked.add(c15);
        }else {
            c15="not";
        }
        if(holder.s16.isChecked()){
            c16="S16 booked";
            booked.add(c16);
        }else {
            c16="not";
        }
        if(holder.s17.isChecked()){
            c17="S17 booked";
            booked.add(c17);
        }else {
            c17="not";
        }
        if(holder.s18.isChecked()){
            c18="S18 booked";
            booked.add(c18);
        }else {
            c18="not";
        }
        if(holder.s19.isChecked()){
            c19="S19 booked";
            booked.add(c19);
        }else {
            c19="not";
        }
        if(holder.s10.isChecked()){
            c20="S20 booked";
            booked.add(c20);
        }else {
            c20="not";
        }



        holder.book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent intent=new Intent(context,Next.class);
               intent.putExtra("amt",cost.get(position).toString());
                intent.putExtra("mo",MainActivity.userid);
                intent.putExtra("o",booked.size());

               context.startActivity(intent);
            }
        });


    }


    @Override
    public int getItemCount() {
        return route.size();

    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView route,busnum,source,destiny,time,cost;
        CheckBox s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20;

        Button book;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            route=itemView.findViewById(R.id.rn);
            busnum=itemView.findViewById(R.id.bn);
            source=itemView.findViewById(R.id.src);
            destiny=itemView.findViewById(R.id.dst);
            time=itemView.findViewById(R.id.tim);
            book=itemView.findViewById(R.id.add);
            cost=itemView.findViewById(R.id.cst);


            s1=itemView.findViewById(R.id.s1);
            s2=itemView.findViewById(R.id.s2);
            s3=itemView.findViewById(R.id.s3);
            s4=itemView.findViewById(R.id.s4);
            s5=itemView.findViewById(R.id.s5);
            s6=itemView.findViewById(R.id.s6);
            s7=itemView.findViewById(R.id.s7);
            s8=itemView.findViewById(R.id.s8);
            s9=itemView.findViewById(R.id.s9);
            s10=itemView.findViewById(R.id.s10);

            s11=itemView.findViewById(R.id.s11);
            s12=itemView.findViewById(R.id.s12);
            s13=itemView.findViewById(R.id.s13);
            s14=itemView.findViewById(R.id.s14);
            s15=itemView.findViewById(R.id.s15);
            s16=itemView.findViewById(R.id.s16);
            s17=itemView.findViewById(R.id.s17);
            s18=itemView.findViewById(R.id.s18);
            s19=itemView.findViewById(R.id.s19);
            s20=itemView.findViewById(R.id.s20);



        }
    }
}
