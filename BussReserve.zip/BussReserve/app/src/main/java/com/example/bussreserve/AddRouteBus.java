package com.example.bussreserve;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AddRouteBus extends AppCompatActivity {

    EditText route_name,busnum,source,desti,time,price;
    CheckBox s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20,s21,s22,s23,s24,s25,s26,s27,s28,s29,s30;

    String c1,ca1,c2,ca2,c3,ca3,c4,ca4,c5,ca5,c6,ca6,c7,ca7,c8,ca8,c9,ca9,c10,ca10,c11,ca11,c12,ca12,c13,ca13,c14,ca14,c15,ca15,c16,ca16,c17,ca17,c18,ca18,c19,ca19,c20,ca20;

    private static final String URL="http://wizzie.tech/Busreservation/add_busrouts.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_route_bus);

        route_name=findViewById(R.id.rtn);
        busnum=findViewById(R.id.busnum);
        source=findViewById(R.id.sorce);
        desti=findViewById(R.id.desti);
        time=findViewById(R.id.tim);
        price=findViewById(R.id.cost);

        s1=findViewById(R.id.s1);s11=findViewById(R.id.s11);s21=findViewById(R.id.s21);
        s2=findViewById(R.id.s2);s12=findViewById(R.id.s12);s22=findViewById(R.id.s22);
        s3=findViewById(R.id.s3);s13=findViewById(R.id.s13);s23=findViewById(R.id.s23);
        s4=findViewById(R.id.s4);s14=findViewById(R.id.s14);s24=findViewById(R.id.s24);
        s5=findViewById(R.id.s5);s15=findViewById(R.id.s15);s25=findViewById(R.id.s25);
        s6=findViewById(R.id.s6);s16=findViewById(R.id.s16);s26=findViewById(R.id.s26);
        s7=findViewById(R.id.s7);s17=findViewById(R.id.s17);s27=findViewById(R.id.s27);
        s8=findViewById(R.id.s8);s18=findViewById(R.id.s18);s28=findViewById(R.id.s28);
        s9=findViewById(R.id.s9);s19=findViewById(R.id.s19);s29=findViewById(R.id.s29);
        s10=findViewById(R.id.s10);s20=findViewById(R.id.s20);s30=findViewById(R.id.s30);

    }


    public void submit(View view) {

        if(s1.isChecked()){
           c1="booked";
        }
        else {
            c1="not";
        }
        if(s2.isChecked()){
            c2="booked";
        }else {
            c2="not";
        }
        if(s3.isChecked()){
            c3="booked";
        }else{
            c3="not";
        }
        if(s4.isChecked()){
            c4="booked";
        }else {
            c4="not";
        }
        if(s5.isChecked()){
            c5="booked";
        }else {
            c5="not";
        }
        if(s6.isChecked()){
            c6="booked";
        }else {
            c6="not";
        }
        if(s7.isChecked()){
            c7="booked";
        }else {
            c7="not";
        }
        if(s8.isChecked()){
            c8="booked";
        }else {
            c8="not";
        }
        if(s9.isChecked()){
            c9="booked";
        }else {
            c9="not";
        }
        if(s10.isChecked()){
            c10="booked";
        }else {
            c10="not";
        }
        if(s11.isChecked()){
            c11="booked";
        }else {
            c11="not";
        }
        if(s12.isChecked()){
            c12="booked";
        }else {
            c12="not";
        }
        if(s13.isChecked()){
            c13="booked";
        }else {
            c13="not";
        }
        if(s14.isChecked()){
            c14="booked";
        }else {
            c14="not";
        }
        if(s15.isChecked()){
            c15="booked";
        }else {
            c15="not";
        }
        if(s16.isChecked()){
            c16="booked";
        }else {
            c16="not";
        }
        if(s17.isChecked()){
            c17="booked";
        }else {
            c17="not";
        }
        if(s18.isChecked()){
            c18="booked";
        }else {
            c18="not";
        }
        if(s19.isChecked()){
            c19="booked";
        }else {
            c19="not";
        }
        if(s10.isChecked()){
            c20="booked";
        }else {
            c20="not";
        }

        if(route_name.getText().toString().trim().isEmpty()){
            Snackbar.make(AddRouteBus.this.getWindow().getDecorView().findViewById(android.R.id.content), "Route Name", Snackbar.LENGTH_SHORT).show();
        }
        else if(busnum.getText().toString().trim().isEmpty()){
            Snackbar.make(AddRouteBus.this.getWindow().getDecorView().findViewById(android.R.id.content), "Bus Number", Snackbar.LENGTH_SHORT).show();
        }
        else if(source.getText().toString().trim().isEmpty()){
            Snackbar.make(AddRouteBus.this.getWindow().getDecorView().findViewById(android.R.id.content), "Source Station", Snackbar.LENGTH_SHORT).show();
        }
        else if(desti.getText().toString().trim().isEmpty()){
            Snackbar.make(AddRouteBus.this.getWindow().getDecorView().findViewById(android.R.id.content), "Destination Station", Snackbar.LENGTH_SHORT).show();
        }

        else if(time.getText().toString().trim().isEmpty()){
            Snackbar.make(AddRouteBus.this.getWindow().getDecorView().findViewById(android.R.id.content), "Time", Snackbar.LENGTH_SHORT).show();
        }
        else if(price.getText().toString().trim().isEmpty()){
            Snackbar.make(AddRouteBus.this.getWindow().getDecorView().findViewById(android.R.id.content), "Price", Snackbar.LENGTH_SHORT).show();
        }
        else {
            fun();
        }

    }

    private void fun() {
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(AddRouteBus.this, ""+response, Toast.LENGTH_SHORT).show();

                try {
                    JSONObject jsonObject=new JSONObject(response);

                    if (jsonObject.getString("result").equals("success")){

                        Snackbar.make(AddRouteBus.this.getWindow().getDecorView().findViewById(android.R.id.content), "Added Success", Snackbar.LENGTH_SHORT).show();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(AddRouteBus.this, error.toString(), Toast.LENGTH_LONG).show();

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String, String>();
                params.put("s1",c1.trim());
                params.put("s2",c2.trim());
                params.put("s3",c3.trim());
                params.put("s4",c4.trim());
                params.put("s5",c5.trim());
                params.put("s6",c6.trim());
                params.put("s7",c7.trim());
                params.put("s8",c8.trim());
                params.put("s9",c9.trim());
                params.put("s10",c10.trim());
                params.put("s11",c11.trim());
                params.put("s12",c12.trim());
                params.put("s13",c13.trim());
                params.put("s14",c14.trim());
                params.put("s15",c15.trim());
                params.put("s16",c16.trim());
                params.put("s17",c17.trim());
                params.put("s18",c18.trim());
                params.put("s19",c19.trim());
                params.put("s20",c20.trim());
                params.put("rn",route_name.getText().toString().trim());
                params.put("bn",busnum.getText().toString().trim());
                params.put("sc",source.getText().toString().trim());
                params.put("ds",desti.getText().toString().trim());
                params.put("t",time.getText().toString().trim());
                params.put("p",price.getText().toString().trim());


                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);


    }
}