package com.example.bussreserve;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AdminHome extends AppCompatActivity {

    TextView qrresult;

    String amount,id,balance,user_balance;

    private static final String URL="http://wizzie.tech/Busreservation/get_conductor.php";
    private static final String BAL_UPDATE="http://wizzie.tech/Busreservation/update_wallet.php";
    private static final String CUN_BAL_UPDATE="http://wizzie.tech/Busreservation/conducter_bal_update.php";
    private static final  String URL1="http://wizzie.tech/Busreservation/get_wallet_balance.php";
    static String mobile=Login.condut_mobile;
    TextView wallet_bal;
    String[]ff;
    int tt,cc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);
        qrresult=findViewById(R.id.result);
        wallet_bal=findViewById(R.id.wallet);

       // Toast.makeText(this, ""+mobile, Toast.LENGTH_SHORT).show();
        getData(mobile);


    }

    private void getData(String mobile) {

        StringRequest stringRequest = new StringRequest(com.android.volley.Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray jsonArray = new JSONArray(response);
                            // Toast.makeText(MainActivity.this, ""+response, Toast.LENGTH_SHORT).show();

                            for (int i = 0; i < jsonArray.length(); i++) {

                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                balance=jsonObject.getString("balance");

                            }
                            wallet_bal.setText(balance.trim());

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();
                params.put("m",mobile);

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if(result != null) {
            if(result.getContents() == null) {
                Log.e("Scan*******", "Cancelled scan");

            } else {
                Log.e("Scan", "Scanned");

               ff=result.getContents().split(",");
               amount=ff[0];
               id=ff[1];
                qrresult.setText(amount);
               // Toast.makeText(this, ""+amount+""+id, Toast.LENGTH_SHORT).show();
               getBalance(id);
               cc=Integer.parseInt(balance)+Integer.parseInt(amount);
               updateConducterWallet(cc,AdminHome.mobile);

              // Toast.makeText(this, amount=ff[0], Toast.LENGTH_SHORT).show();

            }
        } else {
            // This is important, otherwise the result will not be passed to the fragment
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void updateConducterWallet(int cc, String mobile) {
        StringRequest stringRequest=new StringRequest(Request.Method.POST, CUN_BAL_UPDATE, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(AdminHome.this, ""+response, Toast.LENGTH_SHORT).show();

                try {
                    JSONObject jsonObject=new JSONObject(response);

                    if (jsonObject.getString("result").equals("success")){

                        Snackbar.make(AdminHome.this.getWindow().getDecorView().findViewById(android.R.id.content), "Updated Success", Snackbar.LENGTH_SHORT).show();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(AdminHome.this, error.toString(), Toast.LENGTH_LONG).show();

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String, String>();
                params.put("amt",String.valueOf(cc));
                params.put("mob",mobile.trim());

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);


    }

    private void getBalance(String id) {
        StringRequest stringRequest = new StringRequest(com.android.volley.Request.Method.POST, URL1,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray jsonArray = new JSONArray(response);
                             Toast.makeText(AdminHome.this, ""+response, Toast.LENGTH_SHORT).show();

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                user_balance=jsonObject.getString("amount");

                            }

                            tt=Integer.parseInt(user_balance)-Integer.parseInt(amount);
                            updateWallet(tt);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();
                params.put("i",id);
                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }

    private void updateWallet(int tt) {
        StringRequest stringRequest=new StringRequest(Request.Method.POST, BAL_UPDATE, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(AdminHome.this, ""+response, Toast.LENGTH_SHORT).show();

                try {
                    JSONObject jsonObject=new JSONObject(response);

                    if (jsonObject.getString("result").equals("success")){

                        Snackbar.make(AdminHome.this.getWindow().getDecorView().findViewById(android.R.id.content), "Updated Success", Snackbar.LENGTH_SHORT).show();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(AdminHome.this, error.toString(), Toast.LENGTH_LONG).show();

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String, String>();
                params.put("amt",String.valueOf(tt));
                params.put("id",id.trim());

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);


    }

    public void upload(View view) {
        startActivity(new Intent(getApplicationContext(),AddRouteBus.class));
    }

    public void qr(View view) {

        IntentIntegrator integrator = new IntentIntegrator(AdminHome.this);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
        integrator.setPrompt("Scan");
        integrator.setCameraId(0);
        integrator.setBeepEnabled(false);
        integrator.setBarcodeImageEnabled(false);
        integrator.initiateScan();

    }

    public void logout(View view) {

        startActivity(new Intent(getApplicationContext(),Login.class));
        finish();

    }



}