package com.example.bussreserve;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Signup extends AppCompatActivity {

    private static final String URL="http://wizzie.tech/Busreservation/signup.php";
    ArrayList type;
    Spinner usertype;
    Button btnadd;
    EditText etname,etemail,etpassword,etmobile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        usertype = (Spinner)findViewById(R.id.spnrtype);
        btnadd = (Button)findViewById(R.id.btnadd);
        etname = (EditText)findViewById(R.id.etname);
        etemail = (EditText)findViewById(R.id.etemail);
        etpassword = (EditText)findViewById(R.id.etpassword);
        etmobile = (EditText)findViewById(R.id.etmobile);

        type = new ArrayList();
        type.add("User");
        type.add("Conductor");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(Signup.this, android.R.layout.simple_list_item_checked, type);
        usertype.setAdapter(dataAdapter);

        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etname.getText().toString().trim().isEmpty()){
                    Snackbar.make(Signup.this.getWindow().getDecorView().findViewById(android.R.id.content), "Name", Snackbar.LENGTH_SHORT).show();
                }
                else if(etemail.getText().toString().trim().isEmpty()){
                    Snackbar.make(Signup.this.getWindow().getDecorView().findViewById(android.R.id.content), "Email", Snackbar.LENGTH_SHORT).show();
                }
                else if(etpassword.getText().toString().trim().isEmpty()){
                    Snackbar.make(Signup.this.getWindow().getDecorView().findViewById(android.R.id.content), "password", Snackbar.LENGTH_SHORT).show();
                }
                else if(etmobile.getText().toString().trim().isEmpty()){
                    Snackbar.make(Signup.this.getWindow().getDecorView().findViewById(android.R.id.content), "mobile", Snackbar.LENGTH_SHORT).show();
                }
                else {
                    fun();

                }

            }
        });
    }

    private void fun() {
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(Signup.this, ""+response, Toast.LENGTH_SHORT).show();

                try {
                    JSONObject jsonObject=new JSONObject(response);

                    if (jsonObject.getString("result").equals("success")){

                        Snackbar.make(Signup.this.getWindow().getDecorView().findViewById(android.R.id.content), "Added Success", Snackbar.LENGTH_SHORT).show();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(Signup.this, error.toString(), Toast.LENGTH_LONG).show();

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String, String>();

                params.put("nm",etname.getText().toString().trim());
                params.put("em",etemail.getText().toString().trim());
                params.put("ps",etpassword.getText().toString().trim());
                params.put("mb",etmobile.getText().toString().trim());
                params.put("t",usertype.getSelectedItem().toString().trim());

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }


}