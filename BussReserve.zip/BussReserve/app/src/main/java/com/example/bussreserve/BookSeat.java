package com.example.bussreserve;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class BookSeat extends AppCompatActivity {

    RecyclerView recyclerView;
    BookSeatAdapter bookSeatAdapter;

    ArrayList route=new ArrayList();
    ArrayList busnum=new ArrayList();
    ArrayList source=new ArrayList();
    ArrayList destiny=new ArrayList();
    ArrayList time=new ArrayList();
    ArrayList cost=new ArrayList();
    ArrayList s1=new ArrayList(); ArrayList s11=new ArrayList();
    ArrayList s2=new ArrayList(); ArrayList s12=new ArrayList();
    ArrayList s3=new ArrayList(); ArrayList s13=new ArrayList();
    ArrayList s4=new ArrayList(); ArrayList s14=new ArrayList();
    ArrayList s5=new ArrayList(); ArrayList s15=new ArrayList();
    ArrayList s6=new ArrayList(); ArrayList s16=new ArrayList();
    ArrayList s7=new ArrayList(); ArrayList s17=new ArrayList();
    ArrayList s8=new ArrayList(); ArrayList s18=new ArrayList();
    ArrayList s9=new ArrayList(); ArrayList s19=new ArrayList();
    ArrayList s10=new ArrayList(); ArrayList s20=new ArrayList();

    private static final String URL="http://wizzie.tech/Busreservation/getrouts.php";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_seat);
        recyclerView=findViewById(R.id.recycler);

        getData();

    }

    private void getData() {

        route.clear();busnum.clear();source.clear();destiny.clear();time.clear();cost.clear();
        s1.clear();s2.clear();s3.clear();s4.clear();s5.clear();s6.clear();s7.clear();s8.clear();s9.clear();s10.clear();
        s11.clear();s12.clear();s13.clear();s14.clear();s15.clear();s16.clear();s17.clear();s18.clear();s19.clear();s20.clear();

        StringRequest stringRequest = new StringRequest(com.android.volley.Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray jsonArray = new JSONArray(response);
                            // Toast.makeText(MainActivity.this, ""+response, Toast.LENGTH_SHORT).show();

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);

                                route.add(jsonObject.getString("route"));
                                busnum.add(jsonObject.getString("bus_num"));
                                source.add(jsonObject.getString("source"));
                                destiny.add(jsonObject.getString("destiny"));
                                time.add(jsonObject.getString("time"));
                                cost.add(jsonObject.getString("price"));


                                s1.add(jsonObject.getString("s1"));
                                s2.add(jsonObject.getString("s2"));
                                s3.add(jsonObject.getString("s3"));
                                s4.add(jsonObject.getString("s4"));
                                s5.add(jsonObject.getString("s5"));
                                s6.add(jsonObject.getString("s6"));
                                s7.add(jsonObject.getString("s7"));
                                s8.add(jsonObject.getString("s8"));
                                s9.add(jsonObject.getString("s9"));
                                s10.add(jsonObject.getString("s10"));
                                s11.add(jsonObject.getString("s11"));
                                s12.add(jsonObject.getString("s12"));
                                s13.add(jsonObject.getString("s13"));
                                s14.add(jsonObject.getString("s14"));
                                s15.add(jsonObject.getString("s15"));
                                s16.add(jsonObject.getString("s16"));
                                s17.add(jsonObject.getString("s17"));
                                s18.add(jsonObject.getString("s18"));
                                s19.add(jsonObject.getString("s19"));
                                s20.add(jsonObject.getString("s20"));

                            }
                           // Toast.makeText(BookSeat.this, ""+cost.get(0), Toast.LENGTH_SHORT).show();

                            bookSeatAdapter = new BookSeatAdapter(BookSeat.this,route,busnum,source,destiny,time,cost,s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20);
                            recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                            recyclerView.setAdapter(bookSeatAdapter);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();
                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }
}