package com.example.bussreserve;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {

    EditText etemail,etpaswd;
    Button btnlgin;
    TextView tvregister;
    static String user_id,user_mob,condut_mobile;
    private static final String URL="http://wizzie.tech/Busreservation/login.php";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);



        etemail = (EditText)findViewById(R.id.etemail);
        etpaswd = (EditText)findViewById(R.id.etpaswd);
        btnlgin = (Button)findViewById(R.id.btnlgin);
        tvregister = (TextView)findViewById(R.id.tvregister);


        tvregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Signup.class));
            }
        });

        btnlgin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etemail.getText().toString().trim().isEmpty()){
                    Snackbar.make(Login.this.getWindow().getDecorView().findViewById(android.R.id.content), "Email Id", Snackbar.LENGTH_SHORT).show();

                }
                else if(etpaswd.getText().toString().trim().isEmpty()){
                    Snackbar.make(Login.this.getWindow().getDecorView().findViewById(android.R.id.content), "Password", Snackbar.LENGTH_SHORT).show();
                }
                else {
                    fun();
                }
            }
        });
    }

    private void fun() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                       // Toast.makeText(Login.this, ""+response, Toast.LENGTH_SHORT).show();
                        try {
                            JSONArray jsonArray = new JSONArray(response);
                            if (jsonArray.length() == 0) {
                                Toast.makeText(Login.this, "Invalid Credentials", Toast.LENGTH_LONG).show();
                            } else {
                                try {
                                    for (int i = 0; i < jsonArray.length(); i++) {
                                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                                        if(jsonObject.getString("type").equalsIgnoreCase("User")){

                                            user_id=jsonObject.getString("id").trim();
                                            user_mob=jsonObject.getString("mobile").trim();
                                            startActivity(new Intent(getApplicationContext(),MainActivity.class));

                                        }else {

                                            condut_mobile=jsonObject.getString("mobile").trim();
                                            startActivity(new Intent(getApplicationContext(),AdminHome.class));
                                        }

                                       Toast.makeText(getApplicationContext(), "Signed in Successfully", Toast.LENGTH_LONG).show();
                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("a", etemail.getText().toString().trim());
                params.put("b", etpaswd.getText().toString().trim());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }
}