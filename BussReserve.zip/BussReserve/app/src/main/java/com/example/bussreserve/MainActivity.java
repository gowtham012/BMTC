package com.example.bussreserve;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {


    TextView qrresult;
    static String userid=Login.user_id;
    static String mobl=Login.user_mob;
   private static final  String URL="http://wizzie.tech/Busreservation/add_wallet_balance.php";
    private static final  String URL1="http://wizzie.tech/Busreservation/get_wallet_balance.php";


   static String balance;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        qrresult=findViewById(R.id.result);
    }


    public void logout(View view) {

        startActivity(new Intent(getApplicationContext(),Login.class));
        finish();
    }

    public void qr(View view) {
        startActivity(new Intent(getApplicationContext(),Qr.class));

    }

    public void wallet(View view) {

        getwallet();

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Smart Garage");

        // set the custom layout
        final View customLayout = getLayoutInflater().inflate(R.layout.custom_layout, null);
        builder.setView(customLayout);
        final EditText amt=customLayout.findViewById(R.id.amount);
        final TextView balan=customLayout.findViewById(R.id.bal);
        balan.setText(balance);


        // add a button
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                if (amt.getText().toString().trim().isEmpty()) {

                    Snackbar.make(MainActivity.this.getWindow().getDecorView().findViewById(android.R.id.content), "Enter Amount", Snackbar.LENGTH_SHORT).show();
                }

                else {
                    int ss= Integer.parseInt(amt.getText()+balance);
                    StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                           //Toast.makeText(MainActivity.this, ""+response, Toast.LENGTH_SHORT).show();

                            try {
                                JSONObject jsonObject=new JSONObject(response);

                                if (jsonObject.getString("result").equals("success")){

                                    Snackbar.make(MainActivity.this.getWindow().getDecorView().findViewById(android.R.id.content), "Register Successfully", Snackbar.LENGTH_SHORT).show();

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Toast.makeText(MainActivity.this, error.toString(), Toast.LENGTH_LONG).show();

                        }
                    }){
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError {
                            Map<String, String> params=new HashMap<String, String>();
                            params.put("amount",String.valueOf(ss).trim());
                            params.put("id",MainActivity.userid.trim());
                            params.put("mob",MainActivity.mobl.trim());
                            return params;
                        }
                    };
                    RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                    requestQueue.add(stringRequest);

                }

            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {


            }
        });


        AlertDialog dialog = builder.create();
        dialog.show();

    }

    private void getwallet() {
        StringRequest stringRequest = new StringRequest(com.android.volley.Request.Method.POST, URL1,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray jsonArray = new JSONArray(response);
                            // Toast.makeText(MainActivity.this, ""+response, Toast.LENGTH_SHORT).show();

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                balance=jsonObject.getString("amount");

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();
                params.put("m",MainActivity.mobl);
                params.put("i",MainActivity.userid);

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }

    public void book(View view) {
        startActivity(new Intent(getApplicationContext(),BookSeat.class));

    }
}