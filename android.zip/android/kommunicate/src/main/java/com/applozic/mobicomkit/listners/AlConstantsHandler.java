package com.applozic.mobicomkit.listners;

public interface AlConstantsHandler {
    String[] getNotificationTexts();
}
