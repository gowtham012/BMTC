package com.applozic.mobicomkit.listners;

import com.applozic.mobicommons.people.channel.Channel;

public interface AlChannelListener {
    void onGetChannel(Channel channel);
}
