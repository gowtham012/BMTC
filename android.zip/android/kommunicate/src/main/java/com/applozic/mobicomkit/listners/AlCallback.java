package com.applozic.mobicomkit.listners;

public interface AlCallback {
    void onSuccess(Object response);

    void onError(Object error);
}
