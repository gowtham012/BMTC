package com.applozic.mobicomkit.listners;

import com.applozic.mobicommons.people.contact.Contact;

public interface AlContactListener {
    void onGetContact(Contact contact);
}
