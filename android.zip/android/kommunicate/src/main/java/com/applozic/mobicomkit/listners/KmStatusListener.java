package com.applozic.mobicomkit.listners;

public interface KmStatusListener {
    void onStatusChange(String userid, Integer status);
}
