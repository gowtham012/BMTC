package io.kommunicate.callbacks;

import com.applozic.mobicomkit.listners.AlLogoutHandler;

/**
 * Created by ashish on 23/01/18.
 */

public interface KMLogoutHandler extends AlLogoutHandler {
}
