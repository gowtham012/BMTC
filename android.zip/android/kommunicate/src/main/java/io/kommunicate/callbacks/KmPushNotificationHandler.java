package io.kommunicate.callbacks;

import com.applozic.mobicomkit.listners.AlPushNotificationHandler;

/**
 * Created by ashish on 19/04/18.
 */

public interface KmPushNotificationHandler extends AlPushNotificationHandler {
}
