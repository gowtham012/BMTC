package io.kommunicate.users;

import com.applozic.mobicommons.people.contact.Contact;

/**
 * Created by ashish on 30/01/18.
 */

public class KmContact extends Contact {
}
