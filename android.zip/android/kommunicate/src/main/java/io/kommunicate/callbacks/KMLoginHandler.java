package io.kommunicate.callbacks;

import com.applozic.mobicomkit.listners.AlLoginHandler;

/**
 * Created by ashish on 23/01/18.
 */

public interface KMLoginHandler extends AlLoginHandler {

}
