package io.kommunicate.utils;

import com.applozic.mobicommons.commons.core.utils.PermissionsUtils;

/**
 * Created by ashish on 24/01/18.
 */

public class KMPermissionUtils extends PermissionsUtils {
}
