
package io.kommunicate.feeds;


public class Metadata {


}
