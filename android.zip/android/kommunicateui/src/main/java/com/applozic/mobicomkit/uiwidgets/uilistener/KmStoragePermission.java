package com.applozic.mobicomkit.uiwidgets.uilistener;

public interface KmStoragePermission {
    void onAction(boolean didGrant);
}
