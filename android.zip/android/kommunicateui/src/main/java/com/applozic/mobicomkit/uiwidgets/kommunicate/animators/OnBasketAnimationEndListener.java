package com.applozic.mobicomkit.uiwidgets.kommunicate.animators;

public interface OnBasketAnimationEndListener {
    void onAnimationEnd();
}
