package com.applozic.mobicomkit.uiwidgets.uilistener;

import android.content.Context;

/**
 * Created by ashish on 29/01/18.
 */

public interface KmActionCallback {
    void onReceive(Context context, Object object, String action);
}
