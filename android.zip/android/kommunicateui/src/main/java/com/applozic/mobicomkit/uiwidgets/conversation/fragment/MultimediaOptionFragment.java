package com.applozic.mobicomkit.uiwidgets.conversation.fragment;

/**
 * Created with IntelliJ IDEA.
 * User: shai
 * Date: 6/15/14
 * Time: 12:02 PM
 */
public class MultimediaOptionFragment {
    public static final int RESULT_OK = -1;
    public static final int REQUEST_CODE_SEND_LOCATION = 10;
    public static final int REQUEST_CODE_TAKE_PHOTO = 11;
    public static final int REQUEST_CODE_ATTACH_PHOTO = 12;
    public static final int REQUEST_CODE_MULTI_SELECT_GALLERY = 21;
    public static final int REQUEST_MULTI_ATTCAHMENT = 16;
    public static final int REQUEST_CODE_CAPTURE_VIDEO_ACTIVITY = 14;
}
