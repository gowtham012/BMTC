package com.applozic.mobicomkit.uiwidgets;

import androidx.core.content.FileProvider;

/**
 * Created by ashish on 20/04/18.
 */

public class KmFileProvider extends FileProvider {

}
