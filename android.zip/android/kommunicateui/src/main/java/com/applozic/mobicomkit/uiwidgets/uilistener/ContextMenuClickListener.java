package com.applozic.mobicomkit.uiwidgets.uilistener;

import android.view.MenuItem;

/**
 * Created by ashish on 05/02/18.
 */

public interface ContextMenuClickListener {
    boolean onItemClick(int position, MenuItem item);
}
